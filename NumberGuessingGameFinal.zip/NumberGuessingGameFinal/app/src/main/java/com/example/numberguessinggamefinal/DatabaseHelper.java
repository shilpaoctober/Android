package com.example.numberguessinggamefinal;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "GameScores.db";
    private static final int DATABASE_VERSION = 1;

    private static final String TABLE_SCORES = "scores";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_PLAYER_NAME = "player_name";
    private static final String COLUMN_ATTEMPTS = "attempts";
    private static final String COLUMN_WON = "won";
    private static final String COLUMN_TIMESTAMP = "timestamp";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + TABLE_SCORES + "("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_PLAYER_NAME + " TEXT,"
                + COLUMN_ATTEMPTS + " INTEGER,"
                + COLUMN_WON + " INTEGER,"
                + COLUMN_TIMESTAMP + " DATETIME DEFAULT CURRENT_TIMESTAMP"
                + ")";
        db.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_SCORES);
        onCreate(db);
    }

    public void addScore(String playerName, int attempts, boolean won) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COLUMN_PLAYER_NAME, playerName);
        values.put(COLUMN_ATTEMPTS, attempts);
        values.put(COLUMN_WON, won ? 1 : 0);
        // First, try to update existing record for the player
        int rowsAffected = db.update(
                TABLE_SCORES,
                values,
                COLUMN_PLAYER_NAME + " = ?",
                new String[]{playerName}
        );

        // If no existing record was found (rowsAffected == 0), insert a new one
        if (rowsAffected == 0) {
            // Use insertWithOnConflict to handle duplicate entries
            db.insertWithOnConflict(TABLE_SCORES,null,values,SQLiteDatabase.CONFLICT_REPLACE);
        }

        db.close();
    }

    @SuppressLint("Range")
    public List<Score> getAllScores() {
        List<Score> scoreList = new ArrayList<>();
        String selectQuery = "SELECT * FROM " + TABLE_SCORES + " ORDER BY " + COLUMN_ATTEMPTS + " LIMIT 10";

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                Score score = new Score();
                score.setId(cursor.getInt(cursor.getColumnIndex(COLUMN_ID)));
                score.setPlayerName(cursor.getString(cursor.getColumnIndex(COLUMN_PLAYER_NAME)));
                score.setAttempts(cursor.getInt(cursor.getColumnIndex(COLUMN_ATTEMPTS)));
                score.setWon(cursor.getInt(cursor.getColumnIndex(COLUMN_WON)) == 1);
                scoreList.add(score);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return scoreList;
    }
}
