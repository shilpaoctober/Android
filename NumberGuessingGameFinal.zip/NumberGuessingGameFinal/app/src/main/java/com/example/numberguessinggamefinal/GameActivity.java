package com.example.numberguessinggamefinal;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Random;

public class GameActivity extends AppCompatActivity {
    private TextView attemptsText;
    private EditText guessInput;
    private Button submitButton;
    private Button newGameButton;
    private String playerName;
    private int targetNumber;
    private int attempts = 0;
    private final int MAX_ATTEMPTS = 10;
    private int lastGuess = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);
        playerName = getIntent().getStringExtra("PLAYER_NAME");

        attemptsText = findViewById(R.id.attemptsText);
        guessInput = findViewById(R.id.guessInput);
        submitButton = findViewById(R.id.submitButton);
        newGameButton = findViewById(R.id.newGameButton);

        initializeGame();

        submitButton.setOnClickListener(v -> processGuess());
        newGameButton.setOnClickListener(v -> initializeGame());
        ImageView hintIcon = findViewById(R.id.hintIcon);
        hintIcon.setOnClickListener(v -> showHint());

    }

    private void initializeGame() {
        Random random = new Random();
        targetNumber = random.nextInt(100) + 1;
        System.out.println(targetNumber);
        attempts = 0;
        lastGuess = -1;
        updateAttemptsDisplay();
        guessInput.setText("");
        guessInput.setEnabled(true);
        submitButton.setEnabled(true);
    }

    private void processGuess() {
        if (TextUtils.isEmpty(guessInput.getText())) {
            Toast.makeText(this, "Please enter a number", Toast.LENGTH_SHORT).show();
            return;
        }

        int userGuess;
        try {
            userGuess = Integer.parseInt(guessInput.getText().toString());
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Please enter a valid number", Toast.LENGTH_SHORT).show();
            return;
        }

        attempts++;
        lastGuess = userGuess;
        updateAttemptsDisplay();

        if (userGuess == targetNumber) {
            Intent intent = new Intent(GameActivity.this, ScoreActivity.class);
            intent.putExtra("PLAYER_NAME", playerName);
            intent.putExtra("ATTEMPTS", attempts);
            intent.putExtra("RESULT", true);
            startActivity(intent);
            finish();
        } else if (attempts >= MAX_ATTEMPTS) {
            Intent intent = new Intent(GameActivity.this, ScoreActivity.class);
            intent.putExtra("PLAYER_NAME", playerName);
            intent.putExtra("ATTEMPTS", attempts);
            intent.putExtra("RESULT", false);
            startActivity(intent);
            finish();
        } else if (userGuess < targetNumber) {
            Toast.makeText(this, "Too low! Try again.", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Too high! Try again.", Toast.LENGTH_SHORT).show();
        }

        guessInput.setText("");
    }
    private void showHint() {
        String hintMessage;
        if (lastGuess == -1) {
            hintMessage = "Make your first guess!";
        } else if (lastGuess < targetNumber) {
            hintMessage = "Hint: Try a higher number than " + lastGuess;
        } else {
            hintMessage = "Hint: Try a lower number than " + lastGuess;
        }

        // Create a simple hint dialog
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Hint")
                .setMessage(hintMessage)
                .setPositiveButton("OK", (dialog, which) -> dialog.dismiss())
                .show();
    }


    private void updateAttemptsDisplay() {
        attemptsText.setText("Attempt: " + attempts);
    }
}