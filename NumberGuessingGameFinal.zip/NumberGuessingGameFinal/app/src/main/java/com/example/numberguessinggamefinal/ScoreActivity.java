package com.example.numberguessinggamefinal;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import java.util.List;

public class ScoreActivity extends AppCompatActivity {
    private TextView resultText;
    private TextView scoreText;
    private Button newGameButton;
    private ListView scoreListView;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_score);

        dbHelper = new DatabaseHelper(this);

        resultText = findViewById(R.id.resultText);
        scoreText = findViewById(R.id.scoreText);
        newGameButton = findViewById(R.id.newGameButton);
        scoreListView = findViewById(R.id.scoreListView);

        String playerName = getIntent().getStringExtra("PLAYER_NAME");
        int attempts = getIntent().getIntExtra("ATTEMPTS", 0);
        boolean isWin = getIntent().getBooleanExtra("RESULT", false);

        // Save the score to database
        dbHelper.addScore(playerName, attempts, isWin);

        if (isWin) {
            resultText.setText("Congrats " + playerName + "!\nYou guessed in " + attempts + " attempts!");
        } else {
            resultText.setText("Oo Sorry\nYou Failed!");
        }

        scoreText.setText("Attempts: " + attempts);

        // Display high scores
        displayScores();

        newGameButton.setOnClickListener(v -> {
            Intent intent = new Intent(ScoreActivity.this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
            finish();
        });
    }

    private void displayScores() {
        List<Score> scores = dbHelper.getAllScores();
        ScoreAdapter adapter = new ScoreAdapter(scores);
        scoreListView.setAdapter(adapter);
    }

    private class ScoreAdapter extends BaseAdapter {
        private List<Score> scores;

        public ScoreAdapter(List<Score> scores) {
            this.scores = scores;
        }

        @Override
        public int getCount() {
            return scores.size();
        }

        @Override
        public Object getItem(int position) {
            return scores.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = getLayoutInflater().inflate(R.layout.score_item, parent, false);
            }

            Score score = scores.get(position);
            TextView playerNameText = convertView.findViewById(R.id.playerNameText);
            TextView attemptsText = convertView.findViewById(R.id.attemptsText);
            TextView resultText = convertView.findViewById(R.id.resultText);

            playerNameText.setText(score.getPlayerName());
            attemptsText.setText("Attempts: " + score.getAttempts());
            resultText.setText(score.isWon() ? "Won" : "Lost");

            return convertView;
        }
    }
}